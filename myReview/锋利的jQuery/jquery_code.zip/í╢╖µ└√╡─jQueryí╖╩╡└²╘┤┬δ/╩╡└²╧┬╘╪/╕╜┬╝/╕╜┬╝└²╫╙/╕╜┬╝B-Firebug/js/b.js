if( document.getElementById("b") ){
     	document.getElementById("b").innerHTML = " b ";
}