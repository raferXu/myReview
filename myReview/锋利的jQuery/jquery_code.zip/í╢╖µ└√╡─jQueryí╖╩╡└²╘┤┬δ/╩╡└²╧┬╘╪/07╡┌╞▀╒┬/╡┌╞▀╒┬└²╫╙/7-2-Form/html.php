<?php 
	header("Content-Type:text/html; charset=utf-8");
	echo "<div style='background-color:#ffa; padding:20px'>{$_REQUEST['htmlname']},{$_REQUEST['htmladdress']},{$_REQUEST['htmlcomment']}</div>";
?>